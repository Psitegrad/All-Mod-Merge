! Do not use the individual mods if you use the patch mod !
This will cause conflicts.

Patch for:
	(Lequla) Accessory Artifact Items Mod
	(Psitegrad) Buyable Unique Hat
	(Type VETA) Decreased Item Weight
	(Myha) Durability Rebalance
	(Watta) Survival Hatchet
	(Heatnixx) Thousand Men Wedge
	
! This patch must be loaded before Patch - Localization !