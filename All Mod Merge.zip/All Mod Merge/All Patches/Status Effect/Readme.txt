! Do not use the individual mods if you use the patch mod !
This will cause conflicts.


Only fixes the conflict between:
	No Curse Decay
	Status Effect Rebalance

It keeps the disabled curse decay, the rest of status effect is unchanged.