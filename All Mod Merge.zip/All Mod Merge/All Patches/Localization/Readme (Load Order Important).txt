! You need the individual mods to use the patch mod !
They are not contained in the patch.
This will not cause issues if you do not have one of them, but you may notice some modded text for vanilla items / skills.

Localization patch for:
	(Psitegrad) Cooking Rebalance
	(Beardmo) Lore Friendly Skill Names
	(WatashiOurs) Survival Hatchet

The load order is important for the patch only, it must be loaded after these three.
You are free to move the three mods around.

I recommend doing the following for example:
	1st - Cooking Rebalance
	2nd - Lore Friendly Skill Names
	3rd - Survival Hatchet
	4th - Patch - Localization


! This patch must be loaded after Patch - Item !
