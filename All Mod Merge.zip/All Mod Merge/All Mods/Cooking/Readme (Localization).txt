You need the Patch - Localization (Link to it in the folder) if you want to use Cooking Rebalance with either:
	(Beardmo) Lore Friendly Skill Names
	(WatashiOurs) Survival Hatchet

! Make sure to read the readme file for the patch !
