I did not include the BGM mod to keep the file size down.
But you can absolutely get them on your own then paste them here :)

1 - Navigate to C:\Program Files (x86)\Steam\steamapps\common\MadeInAbyss-BSFD\MadeInAbyss-BSFD\usounds\msw\bgm
2 - Make a backup of your current bgm folder (Think about future you).
3 - Paste the archive file, then extract it within the directory
4 - Replace / Override the existing files when asked.
5 - Enjoy !