Almost all of them conflict with each other.
Use the Patch - Item mod to fix this.

Or use one mod at a time (Not Recommanded).