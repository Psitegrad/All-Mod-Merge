Choose one between the two.

If you choose Kukomi's, you will see:
	Small backpack = Small model.
	Medium backpack = Medium model.
	Large backpack = Medium model.

If you choose Bell's, you will see:
	Small backpack = Small model.
	Medium backpack = Small model.
	Large backpack = Small model.

====================================================================================================

You can have both but be aware the latest to load will overwrite the other.
In this case this means deciding on the large backpack texture.

So:
If Bell mod loads last, the game will use that mod to decide which packback to display, you will see:
	Small backpack = Small model.
	Medium backpack = Small model.
	Large backpack = Small model.

If Kukomi mod loads last, the game will use that mod to decide which packback to display, you will see:
	Small backpack = Small model.
	Medium backpack = Small model.
	Large backpack = Medium model.