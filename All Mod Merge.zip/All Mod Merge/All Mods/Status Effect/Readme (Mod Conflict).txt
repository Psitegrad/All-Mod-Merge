Only choose one of the mods, they conflict with each other.
Use the Patch - Status Effect mod to fix this two of them (Link to it in the folder).

Or use one mod at a time (Recommended)