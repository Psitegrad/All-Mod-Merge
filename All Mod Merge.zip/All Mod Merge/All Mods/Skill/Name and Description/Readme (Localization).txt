You need the Patch - Localization (Link to it in the folder) if you want to use Lore Friendly Skill Names and Descriptions with either:
	(Psitegrad) Cooking Rebalance
	(WatashiOurs) Survival Hatchet

! Make sure to read the readme file for the patch !
